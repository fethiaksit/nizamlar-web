/**
 * NİZAMLAR BASKI — CANLI BASKI ÖNİZLEME KONFİGÜRASYONU
 * Mockup modelleri, baskı koordinatları, ürün renkleri ve önceden tanımlı baskı alanları.
 * Directus CMS ve statik JavaScript konfigürasyonuyla %100 uyumludur.
 */

window.NIZAMLAR_MOCKUP_CONFIG = {
  section: {
    tag: 'İnteraktif Stüdyo',
    title: 'Tasarımını Yükle, Baskını Canlı Önizle',
    desc: 'Kendi tasarım dosyanızı yükleyin; tişört, sweatshirt, hoodie, pantolon veya bez çanta üzerinde baskınızın nasıl görüneceğini anında inceleyin.',
    allowedTypesText: 'PNG, JPG, JPEG, WEBP, SVG',
    maxSizeMB: 25,
    tip: 'En iyi sonuç için şeffaf arka planlı PNG dosyası yükleyin.'
  },

  canvas: {
    width: 600,
    height: 680,
    aspectRatio: 600 / 680
  },

  // 12 Renkli Profesyonel Tekstil Renk Kartelası (Önizleme Seçenekleri)
  palette: [
    { id: 'beyaz', name: 'Beyaz', hex: '#F8F8F5' },
    { id: 'siyah', name: 'Siyah', hex: '#202020' },
    { id: 'antrasit', name: 'Antrasit', hex: '#48494B' },
    { id: 'ekru', name: 'Ekru', hex: '#E9DFCB' },
    { id: 'bej', name: 'Bej', hex: '#C6AD8F' },
    { id: 'kahverengi', name: 'Kahverengi', hex: '#674936' },
    { id: 'haki', name: 'Haki', hex: '#666D4F' },
    { id: 'lacivert', name: 'Lacivert', hex: '#242F4A' },
    { id: 'bordo', name: 'Bordo', hex: '#703443' },
    { id: 'kirmizi', name: 'Kırmızı', hex: '#BB343A' },
    { id: 'mavi', name: 'Mavi', hex: '#6B94B4' },
    { id: 'pembe', name: 'Pembe', hex: '#DFA8B6' }
  ],

  samples: [
    {
      id: 'monogram',
      name: 'Nizamlar Atelier',
      category: 'Kurumsal Altın Varak',
      src: 'assets/images/samples/sample-monogram.svg',
      defaultScale: 0.75
    },
    {
      id: 'streetwear',
      name: 'Streetwear Cyber',
      category: '1440 DPI DTF Renkli',
      src: 'assets/images/samples/sample-streetwear.svg',
      defaultScale: 0.85
    },
    {
      id: 'vintage',
      name: 'Varsity 84',
      category: 'Vintage Serigrafi',
      src: 'assets/images/samples/sample-vintage.svg',
      defaultScale: 0.70
    }
  ],

  products: {
    tisort: {
      id: 'tisort',
      name: 'Tişört',
      category: 'Konfeksiyon & Parça',
      spec: '240 GSM Penye Pamuk',
      defaultView: 'front',
      supportedViews: ['front', 'back'],
      defaultColor: 'siyah',
      supportedColors: [
        { id: 'beyaz', name: 'Beyaz', hex: '#F8F8F5' },
        { id: 'siyah', name: 'Siyah', hex: '#202020' },
        { id: 'antrasit', name: 'Antrasit', hex: '#48494B' },
        { id: 'ekru', name: 'Ekru', hex: '#E9DFCB' },
        { id: 'bej', name: 'Bej', hex: '#C6AD8F' },
        { id: 'kahverengi', name: 'Kahverengi', hex: '#674936' },
        { id: 'haki', name: 'Haki', hex: '#666D4F' },
        { id: 'lacivert', name: 'Lacivert', hex: '#242F4A' },
        { id: 'bordo', name: 'Bordo', hex: '#703443' },
        { id: 'kirmizi', name: 'Kırmızı', hex: '#BB343A' },
        { id: 'mavi', name: 'Mavi', hex: '#6B94B4' },
        { id: 'pembe', name: 'Pembe', hex: '#DFA8B6' }
      ],
      views: {
        front: {
          label: 'Ön Görünüm',
          mockups: {
            anthracite: 'assets/images/products/tee-blank-cotton.svg',
            cream: 'assets/images/products/tee-blank-cream.svg'
          },
          printableArea: {
            x: 185,
            y: 145,
            width: 230,
            height: 410,
            label: 'Ön Baskı Alanı (Maks. 38x48 cm)'
          },
          positions: {
            gogus: {
              id: "gogus",
              name: "Sol Göğüs (Cep)",
              x: 245,
              y: 205,
              scale: 0.42,
              rotation: 0,
              desc: "10 x 10 cm Arma / Logo"
            },
            tam_on: {
              id: "tam_on",
              name: "Büyük Ön Baskı (A4/A3)",
              x: 300,
              y: 330,
              scale: 0.95,
              rotation: 0,
              desc: "Geniş A3+ Sanatsal Ön Format"
            },
            sol_gogus: {
              id: 'sol_gogus',
              name: 'Sol Göğüs',
              x: 245,
              y: 205,
              scale: 0.42,
              rotation: 0,
              desc: '10 x 10 cm Arma / Logo'
            },
            sag_gogus: {
              id: 'sag_gogus',
              name: 'Sağ Göğüs',
              x: 355,
              y: 205,
              scale: 0.42,
              rotation: 0,
              desc: '10 x 10 cm Sağ Göğüs Arması'
            },
            orta_gogus: {
              id: 'orta_gogus',
              name: 'Göğüs Orta',
              x: 300,
              y: 245,
              scale: 0.70,
              rotation: 0,
              desc: '20 x 20 cm Tipografik Şerit'
            },
            buyuk_on: {
              id: 'buyuk_on',
              name: 'Büyük Ön Baskı',
              x: 300,
              y: 330,
              scale: 0.95,
              rotation: 0,
              desc: 'Geniş A3+ Sanatsal Ön Format'
            }
          },
          defaultPosition: 'buyuk_on'
        },
        back: {
          label: 'Sırt Görünümü',
          mockups: {
            anthracite: 'assets/images/products/tee-blank-back.svg',
            cream: 'assets/images/products/tee-blank-cream-back.svg'
          },
          printableArea: {
            x: 185,
            y: 135,
            width: 230,
            height: 420,
            label: 'Sırt Baskı Alanı (Maks. 40x50 cm)'
          },
          positions: {
            ense_logo: {
              id: 'ense_logo',
              name: 'Ense / Yaka Altı',
              x: 300,
              y: 165,
              scale: 0.35,
              rotation: 0,
              desc: '8 x 6 cm Ense Mikro Baskı'
            },
            sirt_orta: {
              id: 'sirt_orta',
              name: 'Sırt Orta',
              x: 300,
              y: 260,
              scale: 0.75,
              rotation: 0,
              desc: 'Standart A4 Sırt Yerleşimi'
            },
            sirt_tam: {
              id: "sirt_tam",
              name: "Büyük Sırt Baskısı (A3+)",
              x: 300,
              y: 320,
              scale: 1.10,
              rotation: 0,
              desc: "35 x 45 cm Mega Sırt Sanatı"
            },
            buyuk_sirt: {
              id: 'buyuk_sirt',
              name: 'Büyük Sırt Baskısı',
              x: 300,
              y: 320,
              scale: 1.10,
              rotation: 0,
              desc: '35 x 45 cm Mega Sırt Sanatı'
            }
          },
          defaultPosition: 'buyuk_sirt'
        }
      }
    },

    sweatshirt: {
      id: 'sweatshirt',
      name: 'Sweatshirt',
      category: 'Bisiklet Yaka Ağır Fleece',
      spec: '380 GSM Şardonlu Kumaş',
      defaultView: 'front',
      supportedViews: ['front'],
      defaultColor: 'siyah',
      supportedColors: [
        { id: 'siyah', name: 'Siyah', hex: '#202020' },
        { id: 'antrasit', name: 'Antrasit', hex: '#48494B' },
        { id: 'ekru', name: 'Ekru', hex: '#E9DFCB' },
        { id: 'bej', name: 'Bej', hex: '#C6AD8F' },
        { id: 'kahverengi', name: 'Kahverengi', hex: '#674936' },
        { id: 'haki', name: 'Haki', hex: '#666D4F' },
        { id: 'lacivert', name: 'Lacivert', hex: '#242F4A' },
        { id: 'bordo', name: 'Bordo', hex: '#703443' },
        { id: 'beyaz', name: 'Beyaz', hex: '#F8F8F5' }
      ],
      views: {
        front: {
          label: 'Ön Görünüm',
          mockups: {
            anthracite: 'assets/images/products/sweat-blank-fleece.svg',
            cream: 'assets/images/products/sweat-blank-cream.svg'
          },
          printableArea: {
            x: 180,
            y: 155,
            width: 240,
            height: 400,
            label: 'Sweat Göğüs Alanı (Maks. 38x45 cm)'
          },
          positions: {
            gogus: {
              id: "gogus",
              name: "Sol Göğüs (Cep)",
              x: 245,
              y: 205,
              scale: 0.42,
              rotation: 0,
              desc: "10 x 10 cm Arma / Logo"
            },
            tam_on: {
              id: "tam_on",
              name: "Büyük Ön Baskı (A4/A3)",
              x: 300,
              y: 330,
              scale: 0.95,
              rotation: 0,
              desc: "Geniş A3+ Sanatsal Ön Format"
            },
            sol_gogus: {
              id: 'sol_gogus',
              name: 'Sol Göğüs',
              x: 245,
              y: 215,
              scale: 0.42,
              rotation: 0,
              desc: 'Klasik Minimal Logo'
            },
            sag_gogus: {
              id: 'sag_gogus',
              name: 'Sağ Göğüs',
              x: 355,
              y: 215,
              scale: 0.42,
              rotation: 0,
              desc: 'Sağ Göğüs Logo / Arma'
            },
            on_orta: {
              id: 'on_orta',
              name: 'Ön Orta',
              x: 300,
              y: 260,
              scale: 0.72,
              rotation: 0,
              desc: 'Tipografik Göğüs Şeridi'
            },
            buyuk_on: {
              id: 'buyuk_on',
              name: 'Büyük Ön Baskı',
              x: 300,
              y: 330,
              scale: 0.95,
              rotation: 0,
              desc: 'Geniş Sanatsal Artwork'
            }
          },
          defaultPosition: 'buyuk_on'
        }
      }
    },

    hoodie: {
      id: 'hoodie',
      name: 'Hoodie',
      category: 'Kapüşonlu & Kanguru Cep',
      spec: '400 GSM Ağır Sokak Modası',
      defaultView: 'front',
      supportedViews: ['front'],
      defaultColor: 'siyah',
      supportedColors: [
        { id: 'siyah', name: 'Siyah', hex: '#202020' },
        { id: 'antrasit', name: 'Antrasit', hex: '#48494B' },
        { id: 'ekru', name: 'Ekru', hex: '#E9DFCB' },
        { id: 'bej', name: 'Bej', hex: '#C6AD8F' },
        { id: 'kahverengi', name: 'Kahverengi', hex: '#674936' },
        { id: 'haki', name: 'Haki', hex: '#666D4F' },
        { id: 'lacivert', name: 'Lacivert', hex: '#242F4A' },
        { id: 'bordo', name: 'Bordo', hex: '#703443' },
        { id: 'beyaz', name: 'Beyaz', hex: '#F8F8F5' }
      ],
      views: {
        front: {
          label: 'Ön Görünüm',
          mockups: {
            anthracite: 'assets/images/products/hoodie-blank.svg',
            cream: 'assets/images/products/hoodie-blank-cream.svg'
          },
          printableArea: {
            x: 195,
            y: 175,
            width: 210,
            height: 250,
            label: 'Cep Üstü Baskı Alanı (28x32 cm)'
          },
          positions: {
            gogus: {
              id: "gogus",
              name: "Sol Göğüs (Cep)",
              x: 245,
              y: 205,
              scale: 0.42,
              rotation: 0,
              desc: "10 x 10 cm Arma / Logo"
            },
            tam_on: {
              id: "tam_on",
              name: "Büyük Ön Baskı (A4/A3)",
              x: 300,
              y: 330,
              scale: 0.95,
              rotation: 0,
              desc: "Geniş A3+ Sanatsal Ön Format"
            },
            sol_gogus: {
              id: 'sol_gogus',
              name: 'Sol Göğüs',
              x: 245,
              y: 220,
              scale: 0.40,
              rotation: 0,
              desc: '10x10 cm Minimal Logo'
            },
            sag_gogus: {
              id: 'sag_gogus',
              name: 'Sağ Göğüs',
              x: 355,
              y: 220,
              scale: 0.40,
              rotation: 0,
              desc: 'Sağ Göğüs Logo / Arma'
            },
            on_orta: {
              id: 'on_orta',
              name: 'Ön Orta',
              x: 300,
              y: 255,
              scale: 0.65,
              rotation: 0,
              desc: 'Göğüs Üstü Tipografi'
            },
            cep_ustu: {
              id: 'cep_ustu',
              name: 'Cep Üstü Göğüs (A4)',
              x: 300,
              y: 295,
              scale: 0.85,
              rotation: 0,
              desc: 'Kanguru Cep Üzeri Yerleşim'
            }
          },
          defaultPosition: 'cep_ustu'
        }
      }
    },

    pantolon: {
      id: 'pantolon',
      name: 'Pantolon / Eşofman',
      category: 'Jogger & Parça Kumaş',
      spec: '%100 Pamuk 3 İplik',
      defaultView: 'front',
      supportedViews: ['front'],
      defaultColor: 'siyah',
      supportedColors: [
        { id: 'siyah', name: 'Siyah', hex: '#202020' },
        { id: 'antrasit', name: 'Antrasit', hex: '#48494B' },
        { id: 'ekru', name: 'Ekru', hex: '#E9DFCB' },
        { id: 'bej', name: 'Bej', hex: '#C6AD8F' },
        { id: 'haki', name: 'Haki', hex: '#666D4F' },
        { id: 'lacivert', name: 'Lacivert', hex: '#242F4A' },
        { id: 'kahverengi', name: 'Kahverengi', hex: '#674936' }
      ],
      views: {
        front: {
          label: 'Ön Görünüm',
          mockups: {
            anthracite: 'assets/images/products/jogger-blank.svg',
            cream: 'assets/images/products/jogger-blank-cream.svg'
          },
          printableArea: {
            x: 180,
            y: 110,
            width: 240,
            height: 500,
            label: 'Bacak Baskı Alanı (60x20 cm)'
          },
          positions: {
            ust_uyluk: {
              id: "ust_uyluk",
              name: "Üst Cep / Uyluk",
              x: 240,
              y: 185,
              scale: 0.45,
              rotation: 0,
              desc: "12 x 12 cm Amblem / Cep Yanı"
            },
            yan_paca: {
              id: "yan_paca",
              name: "Yan Bacak / Paça",
              x: 215,
              y: 350,
              scale: 0.68,
              rotation: 0,
              desc: "Dikey Boyuna Tipografi"
            },
            ust_cep: {
              id: 'ust_cep',
              name: 'Üst Cep Bölgesi',
              x: 240,
              y: 185,
              scale: 0.45,
              rotation: 0,
              desc: '12 x 12 cm Amblem / Cep Yanı'
            },
            sol_paca: {
              id: 'sol_paca',
              name: 'Sol Paça',
              x: 220,
              y: 440,
              scale: 0.55,
              rotation: 0,
              desc: 'Sol Ayak Bileği / Paça'
            },
            sag_paca: {
              id: 'sag_paca',
              name: 'Sağ Paça',
              x: 380,
              y: 440,
              scale: 0.55,
              rotation: 0,
              desc: 'Sağ Ayak Bileği / Paça'
            },
            yan_bacak: {
              id: 'yan_bacak',
              name: 'Yan Bacak Baskısı',
              x: 215,
              y: 350,
              scale: 0.68,
              rotation: 0,
              desc: 'Dikey Boyuna Tipografi'
            }
          },
          defaultPosition: 'yan_bacak'
        }
      }
    },

    canta: {
      id: 'canta',
      name: 'Bez Çanta',
      category: 'Ham Pamuk Kanvas Tote',
      spec: '320 GSM Ağır Dayanıklı Dokuma',
      defaultView: 'front',
      supportedViews: ['front'],
      defaultColor: 'ekru',
      supportedColors: [
        { id: 'ekru', name: 'Doğal Ham Bez', hex: '#E9DFCB' },
        { id: 'siyah', name: 'Siyah Kanvas', hex: '#202020' },
        { id: 'bej', name: 'Bej Kanvas', hex: '#C6AD8F' },
        { id: 'haki', name: 'Haki Kanvas', hex: '#666D4F' },
        { id: 'lacivert', name: 'Lacivert Kanvas', hex: '#242F4A' },
        { id: 'beyaz', name: 'Optik Beyaz', hex: '#F8F8F5' }
      ],
      views: {
        front: {
          label: 'Ön Gövde',
          mockups: {
            cream: 'assets/images/products/tote-bag-blank.svg',
            anthracite: 'assets/images/products/tote-bag-black.svg'
          },
          printableArea: {
            x: 180,
            y: 230,
            width: 240,
            height: 330,
            label: 'Çanta Ön Yüzü (28x35 cm)'
          },
          positions: {
            ust_orta: {
              id: 'ust_orta',
              name: 'Üst Orta',
              x: 300,
              y: 310,
              scale: 0.60,
              rotation: 0,
              desc: 'Ağız Kısmı Altı Üst Yerleşim'
            },
            orta_baski: {
              id: 'orta_baski',
              name: 'Orta Baskı',
              x: 300,
              y: 380,
              scale: 0.88,
              rotation: 0,
              desc: 'Dengeli A4 Merkez Baskı'
            },
            buyuk_on: {
              id: 'buyuk_on',
              name: 'Büyük Ön Baskı',
              x: 300,
              y: 375,
              scale: 1.12,
              rotation: 0,
              desc: 'Tüm Gövdeyi Kaplayan Sanatsal Baskı'
            }
          },
          defaultPosition: 'orta_baski'
        }
      }
    }
  }
};
